/*
 * optimisation_problem.cpp
 *
 *  Created on: Jan 20, 2014
 *      Author: ctsotskas
 */



#include "optimisation_problem.h"


class optimisation_problem{


public:
	optimisation_problem();
};
