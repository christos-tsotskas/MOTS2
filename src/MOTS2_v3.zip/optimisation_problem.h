/*
 * optimisation_problem.h
 *
 *  Created on: Jan 20, 2014
 *      Author: ctsotskas
 */

#ifndef OPTIMISATION_PROBLEM_H_
#define OPTIMISATION_PROBLEM_H_




#endif /* OPTIMISATION_PROBLEM_H_ */
