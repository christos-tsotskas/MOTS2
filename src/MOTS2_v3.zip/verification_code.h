
#include "global_defines.h"

ObjFunction2 simple_read_vector_from_file(std::string filename);
